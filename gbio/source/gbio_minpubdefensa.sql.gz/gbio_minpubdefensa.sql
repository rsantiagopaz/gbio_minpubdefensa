-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-12-2018 a las 08:07:40
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `id_departamento` int(11) NOT NULL,
  `id_provincia` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `empleado`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `empleado` (
`id_empleado` int(11)
,`enroll_number` int(11)
,`name` varchar(23)
,`nro_doc` int(11)
,`apellido` varchar(50)
,`nombre` varchar(100)
,`privilege` tinyint(1)
,`enabled` tinyint(1)
,`id_lugar_trabajo` int(11)
,`id_tolerancia` int(11)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_datos`
--

CREATE TABLE `empleado_datos` (
  `id_empleado` int(11) NOT NULL,
  `privilege` tinyint(1) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `id_tolerancia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `empleado_datos`
--

INSERT INTO `empleado_datos` (`id_empleado`, `privilege`, `enabled`, `id_lugar_trabajo`, `id_tolerancia`) VALUES
(130, 3, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_ori`
--

CREATE TABLE `empleado_ori` (
  `id_empleado` int(11) NOT NULL,
  `enroll_number` int(11) DEFAULT NULL COMMENT 'Nro de Legajo',
  `name` varchar(23) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'Nombre que figurara en el lector',
  `password` varchar(8) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT '?',
  `privilege` tinyint(4) DEFAULT '0' COMMENT '0=Usuario, 1=Administrador',
  `enabled` tinyint(1) DEFAULT NULL COMMENT '0=False, 1=True',
  `nro_doc` int(11) DEFAULT NULL,
  `apellido` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nacimiento` date DEFAULT NULL,
  `sexo` enum('F','M') COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado_civil` enum('S','C','D','V') COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'S=Soltero, C=Casado, D=Divorciado, V=Viudo',
  `domicilio` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_ubicacion` int(11) DEFAULT NULL,
  `email` varchar(70) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `celular` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ingreso` date DEFAULT NULL COMMENT 'Fecha de Ingreso a la Empresa',
  `condicion_laboral` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `contrato_desde` date DEFAULT NULL,
  `contrato_hasta` date DEFAULT NULL,
  `id_organigrama` int(11) DEFAULT NULL COMMENT 'Id de la hoja del arbol del organigrama de la empresa',
  `categoria` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `funcion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `ficha_pin` enum('S','N') COLLATE utf8_spanish_ci DEFAULT 'N' COMMENT 'Si permite o no fichar con Pin',
  `foto` blob,
  `id_tolerancia` int(11) DEFAULT NULL,
  `id_lugar_trabajo` int(11) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `empleado_ori`
--

INSERT INTO `empleado_ori` (`id_empleado`, `enroll_number`, `name`, `password`, `privilege`, `enabled`, `nro_doc`, `apellido`, `nombre`, `nacimiento`, `sexo`, `estado_civil`, `domicilio`, `id_ubicacion`, `email`, `telefono`, `celular`, `ingreso`, `condicion_laboral`, `contrato_desde`, `contrato_hasta`, `id_organigrama`, `categoria`, `funcion`, `ficha_pin`, `foto`, `id_tolerancia`, `id_lugar_trabajo`) VALUES
(1, 1, '', '25802', 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 1),
(2, 28086203, 'De la rua Rodrigo', '', 3, 1, 28086203, 'De la Rua', 'Rodrigo', '2013-06-11', 'M', 'S', 'La Plata 1242- 1º piso Dpto Nº9 Bº Alberdi', 2, '', '', '155132904', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(3, 26368440, 'Zurita, Vanesa', '', 0, 1, 26368440, 'Zurita', 'Vanesa Andrea', '1899-11-30', 'F', 'S', 'Santa Cruz Nº 616 Bº Parque', 2, '', '4218319', '154747700', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(4, 24522419, 'Perotti, Vanina', '', 0, 1, 24522419, 'Perotti', 'Vanina Guadalupe', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '2023-11-09', 0, '', '', 'N', '', 1, 1),
(5, 23203433, 'Enriquez, Jose', '', 0, 1, 23203433, 'Enriquez', 'José María', '1899-11-30', 'M', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', NULL, 1),
(6, 34243998, 'Ybarra, Martin', '', 0, 1, 34243998, 'Ybarra', 'Oscar Martín', '1899-11-30', 'M', 'S', 'Constitucion Nº23 Clodomira', 2, '', '4921708', '155943515', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(7, 23042889, 'Beltran de la Silva, Gu', '', 0, 1, 23042889, 'Beltran De la Silva', 'Gustavo', '1899-11-30', 'M', 'D', 'Mza 2 lote 17 Bº los Flores', 2, 'gusydelasilva@hotmail.com', '3855841760', '3855393180', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(8, 24376208, 'Sanchez, Ramona', '', 0, 1, 24376208, 'Sanchez', 'Ramona Esther', '1899-11-30', 'F', 'C', '12 de Octubre Nº 179', 2, '', '4255034', '155154205', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(9, 22618178, 'Carabajal, Walter', '', 0, 1, 22618178, 'Carabajal', 'Walter', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 1),
(10, 27608108, 'Cura, Ornella', '', 0, 1, 27608108, 'Cura', 'Ornella Fabina', '1899-11-30', 'F', 'S', 'Balcarce Nº 68', 2, '', '4240770', '154817471', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(11, 16771975, 'Casares, Roxana', '', 0, 1, 16771975, 'Casares', 'Roxana', '1899-11-30', 'F', 'C', 'Casa 24 Grupo 7 B° Misky MAyu', 2, 'casaresroxana', '4371782', '154103389', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(12, 12935883, 'Lezana, Nestor', '', 0, 1, 12935883, 'Lezana', 'Nestor Elpidio', '1899-11-30', 'M', 'C', 'Julian y Benicio Diaz Nº 917 Bº Tradicion', 2, '', '4312742', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(13, 8790511, 'Gallo, Manuel', '', 0, 1, 8790511, 'Gallo', 'Manuel Antonio', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(14, 28247912, 'Diaz, Diego', '', 0, 1, 28247912, 'Diaz', 'Diego Fernando', '1899-11-30', 'M', 'C', 'Mza 22 lote 22 Bº Campo Contreras(viejo)', 2, '', '', '155767491', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(15, 12075052, 'Serrano, Miguel', '', 0, 1, 12075052, 'Serrano', 'Miguel Demetrio', '0000-00-00', 'F', 'S', 'Peru 546', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 1),
(16, 14272618, 'Bravo, Leonidas', '', 0, 1, 14272618, 'Bravo', 'Leonidas del Jesús', '1899-11-30', 'M', 'S', 'Formosa Nº 648', 2, '', '', '154332839', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(17, 23041456, 'Dell Aringa, Cecilia', '', 0, 1, 23041456, 'Dell Aringa', 'María Cecilia', '1899-11-30', 'F', 'C', 'Mza 39 lote 21 Bº siglo XIX', 2, '', '4253728', '155173263', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(18, 34981776, 'Serrano, Noelia', '', 0, 1, 34981776, 'Serrano', 'Noelia Giselle', '1899-11-30', 'F', 'S', 'Belgrano S) Nº 888 1piso Dpto E', 2, '', '', '155196457', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(19, 18090601, 'Salazar, Cesar', '', 0, 1, 18090601, 'Salazar', 'Cesar Rodolfo', '1899-11-30', 'M', 'C', 'Republica del Libano Nº 857 L. B.', 2, '', '4274590', '154779579', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(20, 12391148, 'Alzugaray, Guadalupe', '', 0, 0, 12391148, 'Alzugaray', 'María Guadalupe', '1899-11-30', 'F', 'C', 'Mza 49 Lote 26 Bº Siglo XX', 2, '', '', '154386244', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(21, 28246215, 'Gomez, Andrea', '', 0, 1, 28246215, 'Gomez', 'Andrea Adriana', '1899-11-30', 'F', 'S', 'Pje. Albert Sabin Nº 267 Bº Sarmiento', 2, '', '4254699', '155908935', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(22, 17438026, 'Diaz, Fabian', '', 0, 1, 17438026, 'Diaz', 'Walter Fabian', '1899-11-30', 'M', 'S', 'Mza 37 L4 Bº San Fernando La Banda', 2, '', '', '155871762', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(23, 26161378, 'Veron, Mario', '', 0, 1, 26161378, 'Veron', 'Mario de Jesús', '1899-11-30', 'M', 'S', 'T78 2 PDpto C Bº Autonomia', 2, '', '4395276', '155099698', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(24, 10301819, 'Gonzalez, Juan', '', 0, 1, 10301819, 'Gonzalez', 'Juan Segundo', '1899-11-30', 'M', 'S', 'Mza.2 Lote 23 Bº 1 de Mayo', 2, '', '4259738', '154977462', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(25, 16309980, 'Gerez, Nora', '', 0, 1, 16309980, 'Gerez', 'Nora Beatriz', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '4310039', '155060342', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(26, 27475336, 'Morales, Luis', '', 3, 1, 27475336, 'Morales', 'Luis Gabriel', '1980-01-01', 'M', 'S', 'Peru 546', 2, '', '', '', '1980-01-01', '', '1980-01-01', '2100-01-01', 0, '', '', 'N', '', 1, 1),
(27, 26448750, 'Navarrete, Claudia', '', 0, 1, 26448750, 'Navarrete', 'Claudia Alejandra', '0000-00-00', 'F', 'S', 'Peru 546', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 1),
(28, 25023042, 'Gomez, Gabriel', '', 0, 1, 25023042, 'Gomez', 'Luis Gabriel', '1899-11-30', 'M', 'S', 'Balcarse Nº 68', 2, '', '4240770', '155134975', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(29, 33234756, 'Campos, Cinthia', '', 0, 1, 33234756, 'Campos', 'Cinthia Noelia', '1899-11-30', 'F', 'S', 'mza c l 22 ºbº Los Alomos', 2, '', '4216193', '155806926', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(30, 31739198, 'Castellini, Cecilia', '', 0, 1, 31739198, 'Castellini', 'Cecilia', '1899-11-30', 'F', 'S', 'Peru 825', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(31, 21022533, 'Cuenca, Marcos', '', 0, 1, 21022533, 'Cuenca Pizarro', 'Marcos', '1899-11-30', 'M', 'C', '24 de septiembre Nº 140 Bº Centro', 2, '', '4210843', '154881543', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(32, 23886304, 'Trouve, Jorgelina', '', 0, 1, 23886304, 'Trouve', 'Jorgelina', '0000-00-00', 'F', 'S', 'Las Magnolias 3207 Bº Jardin', 2, '', '4313469', '154121566', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', 1, 1),
(33, 27475039, 'Trejo, Victor', '', 0, 1, 27475039, 'Trejo', 'Victor Arnaldo', '1899-11-30', 'F', 'S', 'Mza E Lote 18 Bº Siglo 21', 2, '', '', '155025299', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(34, 32055325, 'Ybarra, Gimena', '', 0, 1, 32055325, 'Ibarra', 'Jimena Verónica', '1899-11-30', 'F', 'C', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(35, 30441793, 'Brandan, Mariana', '', 0, 1, 30441793, 'Brandan', 'Hilda Mariana', '1899-11-30', 'F', 'S', 'mza 47 l 21 BºSaint Germes', 2, '', '', '155949430', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(36, 23411503, 'Aragon, Adolfo', '', 0, 1, 23411503, 'Aragon', 'Adolfo Alejandro', '1899-11-30', 'M', 'S', 'Ab. Rojas  Nº 485 Bº Alberdi', 2, '', '', '154814762', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(37, 26560784, 'Bravo, Diego', '', 0, 1, 26560784, 'Bravo', 'Diego Fernando', '1979-04-27', 'M', 'C', 'Dorrego Nº413 Bº 8 de Abril', 2, '', '4217086', '154847581', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(38, 28246005, 'Fernandez, Gerardo', '', 0, 0, 28246005, 'Fernandez', 'Gerardo Fabián', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', NULL, 1),
(39, 10936270, 'Brondo, Jorge', '', 0, 1, 10936270, 'Brondo', 'Jorge Ignacio', '1899-11-30', 'M', 'S', 'San Lorenzo 3105 Bº Juramento', 2, '', '4317161', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(40, 10910610, 'Rueda, Gustavo', '', 0, 1, 10910610, 'Rueda', 'Gustavo Adolofo', '0000-00-00', 'F', 'S', 'Peru 546', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 1),
(41, 21968673, 'Coronel Palavecino, Edu', '', 0, 1, 21968673, 'Coronel Palavecino', 'Eduardo Antonio', '1899-11-30', 'F', 'S', 'Pablo Splinder 549 Bº Jorge Newbery', 2, '', '', '155827774', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(42, 16329511, 'Ybarra, Oscar', '', 0, 1, 16329511, 'Ybarra', 'Oscar Eduardo', '1899-11-30', 'M', 'S', 'Constitucion Nº 23', 2, '', '4921708', '154982361', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(43, 11493817, 'Hernandez, Daniel O.', '', 0, 1, 11493817, 'Hernandez', 'Daniel Orlando', '1899-11-30', 'M', 'C', 'Congreso Nº 1132 Bº Pra Junta', 2, '', '4241760', '154326521', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(44, 11143647, 'Gomez, Oscar Eduardo', '', 0, 1, 11143647, 'Gomez', 'Oscar Eduardo', '1899-11-30', 'M', 'S', 'Pedro Leon Gallo Nº 2104 Bº Libertad', 2, '', '4395957', '154823701', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(45, 24193220, 'Suarez, Lionel Enrrique', '', 0, 1, 24193220, 'Suarez', 'Lionel Enrrique', '0000-00-00', 'M', 'S', 'la banda', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', 1, 1),
(46, 24494197, 'Cremaschi, Licciana', '', 0, 0, 24494197, 'Cremaschi', 'Lucciana', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(47, 27081498, 'Rodriguez, Cecilia', '', 0, 0, 27081498, 'Rodriguez Figueroa', 'María Cecilia del Valle', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(48, 14350952, 'Carabajal, Luis Ramon', '', 0, 1, 14350952, 'Carabajal', 'Luis Ramon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 1),
(49, 18037082, 'Zaltz, Sergio R.', '', 0, 1, 18037082, 'Zaltz', 'Sergio R.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 1),
(50, 18259969, 'Massaro, Emilio', '', 0, 1, 18259969, 'Massaro', 'Emilio Mario Alejandro', '1899-11-30', 'M', 'S', '12 de Ocubre 179 Bº Francisco de Aguirre', 2, '', '4255034', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(51, 21631209, 'Greco, David', '', 0, 1, 21631209, 'Greco', 'David Fabián', '1970-06-06', 'M', 'S', 'Mza. 26 Lote 25 Bº Los Flores', 2, '', '4257878', '154162950', '1997-02-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(52, 25596614, 'Gomez, Carolina', '', 0, 0, 25596614, 'Gomez', 'Elena Carolina', '1899-11-30', 'F', 'S', 'Peru 546', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(53, 31487676, 'Spescha, Noelia', '', 0, 1, 31487676, 'Spescha', 'Noelia', '1985-09-03', 'F', 'S', 'Mendoza 82 - 4º E', 2, 'estudio.spescha@hotmail.com', '', '3816206494', '1899-11-30', '', '2014-01-01', '2014-12-31', 0, '', '', 'N', '', 1, 1),
(54, 32285310, 'Rivero Vanesa', '', 0, 1, 32285310, 'Rivero', 'Claudia Vanesa', '1899-11-30', 'F', 'S', 'Cabo San Pablo Nº 36 P1 Dpto 8g', 2, 'clau01@hotmail.com', '', '3856981958', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(55, 21112455, 'Corvalan Miguel A', '', 0, 1, 21112455, 'Corvalan', 'Miguel Angel', '1970-12-25', 'M', 'C', 'Mza M L 10 Bº M Moreno', 2, '', '4315325', '3854856503', '1899-11-30', '', '2014-01-01', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(56, 32055134, 'Fernandez Ana', '', 0, 1, 32055134, 'Fernandez', 'Ana Eugenia', '1899-11-30', 'F', 'S', 'Mza 24 l 32 Bº Saint Germes', 2, 'anaf17@hotmail.com', '', '3855048076', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', NULL, 1),
(57, 23410747, 'Castaño Karina', '', 0, 1, 23410747, 'Castaño', 'Karina Alejandra del Valle', '1973-10-11', 'F', 'D', 'Mza H lote 19 Bº  Siglo XXI', 2, 'kary_alecasta@hotmail.com', '', '3855933956', '1899-11-30', '', '2014-01-01', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(58, 29376627, 'Rueda Amelia', '', 0, 1, 29376627, 'Rueda', 'Maria Amelia', '1899-11-30', 'F', 'S', 'Mza 3 L 25 Bº Villa del Carmen', 2, 'amely533@hotmail.com', '', '3854068994', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(59, 23687897, 'Infante Adriana', '', 0, 1, 23687897, 'Infante', 'Adriana Silvina', '1974-01-14', 'F', 'S', 'Mza G L19 2da Amp Borges', 2, '', '', '154064672', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(60, 37836211, 'Fernandez Ramiro', '', 0, 1, 37836211, 'Fernandez', 'Ramiro', '1899-11-30', 'M', 'C', 'España 1180 Bº Los Inmigranes', 2, 'ramirofernandez@hotmail.com', '4215027', '155839235', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(61, 37131704, 'Coronel Gabriel', '', 0, 1, 37131704, 'Coronel Arce', 'Gabriel Alejandro ', '1899-11-30', 'M', 'S', 'Calle 57 Nº 75 Bº Ej. Arg.', 2, 'gabrielcoronel 1410@hotmail.com.ar', '', '154094365', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(62, 33791384, 'Bode Alejo', '', 0, 1, 33791384, 'Bode Bravo', 'Alejo', '1899-11-30', 'M', 'S', 'Lavalle 3038 Mza A lote 2 Bº Ampliacion Santa Lucia', 2, 'alejo.rc73@gmail.com', '', '154382965', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(63, 35345152, 'Orieta Roberto', '', 0, 1, 35345152, 'Orieta Chavez', 'Orieta Chavez', '1899-11-30', 'M', 'S', 'Rodriguez 148 Bº Ramon Carrillo', 2, 'luciano_orieta@hotmail.com', '4219681', '156970459', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(64, 26368116, 'Pallares Angel', '', 0, 1, 26368116, 'Pallares', 'Angel Roberto', '1899-11-30', 'M', 'S', 'Av. Rivadavia 2268', 2, 'pallaresangel@gmail.com', '4391171', '154745700', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(65, 28139717, 'Villa Pedro', '', 0, 1, 28139717, 'Villa', 'Pedro Daniel', '1899-11-30', 'M', 'S', 'Capitan Aguado 1056 Bº San Martin', 2, '', '', '155844883', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(66, 25946932, 'Villa Mario', '', 0, 1, 25946932, 'Villa Micó', 'Mario Gines', '1899-11-30', 'M', 'S', 'Calle 202 Nº1292 Bº Huaico Hondo', 2, 'checkas22dagosto@yahoo.com.ar', '', '155954490', '2014-03-07', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(67, 30918387, 'Toloza Andrea', '', 0, 1, 30918387, 'Toloza', 'Maria Andrea', '1899-11-30', 'F', 'S', 'Sarmiento 732 Bº Francisco de Aguirre', 2, 'andriquita@hotmail.com', '', '155176928', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(68, 24840090, 'Santucho Francisco', '', 0, 1, 24840090, 'Santucho', 'Francisco Rene', '1899-11-30', 'M', 'S', 'Mza 25 Lote 5 Bº Smata', 2, 'francisco_santucho@yahoo.com.ar', '4396545', '154718699', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(69, 22429155, 'Murad Adriana', '', 0, 1, 22429155, 'Murad', 'Rosa Adriana', '1899-11-30', 'F', 'S', 'Mza 69 Lote 24 Bº Sait Germain', 2, 'laturca09@live.com.ar', '', '155819517', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(70, 28139941, 'Drube Leandro', '', 0, 1, 28139941, 'Drube', 'Leandro Javier', '0000-00-00', 'M', 'S', 'Pellegrini 468', 2, 'estudiodrube@arnet.com.ar', '4211975', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 1),
(71, 30441619, 'Drube Andres', '', 0, 1, 30441619, 'Drube', 'Andres Mariano', '1899-11-30', 'F', 'S', 'Pellegrini 468', 2, 'estudiodrube@arnet.com.ar', '4211975', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(72, 16007194, 'Auad Ricardo', '', 0, 1, 16007194, 'Auad', 'Ricardo Abdala', '1899-11-30', 'M', 'S', 'Independencia 580', 2, 'ricardoauad@hotmail.com.ar', '4212783', '3856983444', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(73, 23041752, 'Paz Soria Claudia', '', 0, 1, 23041752, 'Paz Soria', 'Claudia Beatriz', '1899-11-30', 'F', 'S', 'Mza 36 lote 5 Bº Saint Germes', 2, 'aypa02@hotmail.com', '', '3855893264', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(74, 30241421, 'Paz Alejandro', '25802', 3, 1, 30241421, 'Paz1', 'Alejandro1', '1899-11-30', 'M', 'S', 'B vinalar', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(75, 18755038, 'Mukdise Veronica', '', 0, 1, 18755038, 'Mukdise', 'Veronica D.', '1899-11-30', 'F', 'S', 'Hernandarias Nº 230 Bº Cabildo', 2, '', '', '', '2014-07-28', '', '2014-07-28', '2014-07-28', 0, '', '', 'N', '', NULL, 2),
(76, 18518481, 'Jorge Maria', '', 0, 0, 18518481, 'Jorge', 'Maria C.', '0000-00-00', 'F', 'S', 'Mza 8 Lote 15 Bº 1º Ampl. Altte Brown', 2, '', '', '', '2014-07-28', NULL, '2014-07-28', '2014-07-28', 0, NULL, NULL, 'N', NULL, NULL, 2),
(77, 8134111, 'Pacheco Ricardo', '', 0, 1, 8134111, 'Pacheco', 'Ricardo P.', '1899-11-30', 'M', 'S', 'Mza 13 Lote 2 Bº Smata', 2, '', '', '', '2014-07-28', '', '2014-07-28', '2014-07-28', 0, '', '', 'N', '', NULL, 2),
(78, 16802681, 'Ferreyra Jose', '', 0, 1, 16802681, 'Ferreyra', 'Jose R.', '1899-11-30', 'M', 'S', 'Calle 3 Nº 252 Bº Ampl I de Mayo (LB)', 2, '', '', '', '2014-07-28', '', '2014-07-28', '2014-07-28', 0, '', '', 'N', '', NULL, 2),
(79, 16309921, 'Juarez Hugo', '', 0, 1, 16309921, 'Juarez', 'Hugo W.', '1899-11-30', 'M', 'S', 'Mza 47 Lote 12 Bº Campo Contreras', 2, '', '', '', '2014-07-28', '', '2014-07-28', '2014-07-28', 0, '', '', 'N', '', NULL, 2),
(80, 13775263, 'Heredia Enrique', '', 0, 1, 13775263, 'Heredia', 'Enrique M.', '0000-00-00', 'F', 'S', 'Mza 13 Lote 20 Bº Paraiso (L.B.)', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(81, 23294625, 'Coronel Alcides', '', 0, 1, 23294625, 'Coronel', 'Alcides D.', '0000-00-00', 'M', 'S', 'Juan F. Ibarra Nº 605 Bº Autonomia', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(82, 22243379, 'Almaras Luis', '', 0, 1, 22243379, 'Almaras', 'Luis M.', '1899-11-30', 'F', 'S', 'Santiago Palacios Nº 455 Bº Huaico Hondo', 2, 'Almaras Luis', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', NULL, 2),
(83, 18260080, 'Garcia Roxana', '', 0, 1, 18260080, 'Garcia', 'Roxana B.', '0000-00-00', 'F', 'S', 'San Luis Nº 1226 Bº Sarmiento', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(84, 26640885, 'Toloza Marta', '', 0, 1, 26640885, 'Toloza', 'Martha S.', '0000-00-00', 'F', 'S', 'Martin Fierro Nº 461 Bº Reconquista', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(85, 16308910, 'Cabañas Alejandro', '', 0, 1, 16308910, 'Cabañas', 'Alejandro M.', '0000-00-00', 'M', 'S', 'Mza 2 Lote 6 Bº Paraiso (L.B.)', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(86, 17438480, 'Corvalan Arnaldo', '', 0, 1, 17438480, 'Corvalan', 'Arnaldo A.', '0000-00-00', 'M', 'S', 'Av. Belgrano (s) 4770 Bº Altte. Brown', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(87, 14543712, 'Raed Carlota', '', 0, 1, 14543712, 'Raed', 'Carlota Judith M.', '0000-00-00', 'F', 'S', 'Olaechea Nº 925 Bº Parque', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(88, 30712102, 'Argañaras Santiago', '', 0, 1, 30712102, 'Argañaras', 'Santiago A.', '0000-00-00', 'M', 'S', '24 Septiembre Nº 665', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(89, 28246189, 'Carabajal Silvina', '', 0, 1, 28246189, 'Carabajal', 'Silvina A.', '0000-00-00', 'F', 'S', 'Santa Fe Nº 186 Dpto. 3 Bº Congreso', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(90, 16007564, 'Pece Magali', '', 0, 1, 16007564, 'Pece', 'Magali del C.', '0000-00-00', 'F', 'S', 'Independencia Nº 520 Bº Centro', 2, '', '', '', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', NULL, 2),
(91, 27392154, 'Rojas Analia', '', 0, 1, 27392154, 'Rojas', 'Analia V.', '1899-11-30', 'F', 'S', 'Mza 5 Lote 6 Bº mariano Moreno', 2, '', '', '', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', NULL, 2),
(94, 18090821, 'Barreto, Carlos', '', 0, 1, 18090821, 'Barreto', 'Carlos C.', '1899-11-30', 'M', 'S', 'Mza 2 Lote 6 Bº Paraiso (L.B.)', 2, '', '', '', '2014-08-13', '', '2014-08-13', '2014-08-13', 0, '', '', 'N', '', NULL, 2),
(95, 27608086, 'Navelino M', '', 0, 1, 27608086, 'Navelino', 'Maria del R.', '1899-11-30', 'F', 'S', 'Buenos Aires 2587 Bº Reconquista', 2, '', '', '', '2014-08-13', '', '2014-08-13', '2014-08-13', 0, '', '', 'N', '', NULL, 2),
(99, 20898041, 'Ardisone Silvia', '', 0, 1, 20898041, 'Ardisone', 'Silvia G.', '0000-00-00', 'F', 'S', 'Sin Domicilio', 2, '', '', '', '2014-08-13', NULL, '2014-08-13', '2014-08-13', 0, NULL, NULL, 'N', NULL, NULL, 2),
(100, 28139818, 'Meneguin Carolina', '', 0, 1, 28139818, 'Meneghin', 'Carolina', '0000-00-00', 'F', 'S', 'Chaco Nº 452', 2, '', '', '', '2014-08-13', NULL, '2014-08-13', '2014-08-13', 0, NULL, NULL, 'N', NULL, NULL, 2),
(101, 21339369, 'Bazquez Olga', '', 0, 1, 21339369, 'Bazquez', 'Olga B.', '1899-11-30', 'F', 'S', 'Ceferino Namuncura Nº 427 Bº Reconquista', 2, '', '', '', '2014-08-13', '', '2014-08-13', '2014-08-13', 0, '', '', 'N', '', NULL, 2),
(102, 31311705, 'Lezana Sandra', '', 0, 1, 31311705, 'Lezana', 'Sandra E.', '0000-00-00', 'F', 'S', 'Julian y Benicio Diaz Nº 917 Bº Tradicion', 2, '', '', '', '2014-08-13', NULL, '2014-08-13', '2014-08-13', 0, NULL, NULL, 'N', NULL, NULL, 2),
(104, 24346800, 'Tello Daniel', '', 0, 1, 24346800, 'Tello', 'Daniel M.', '0000-00-00', 'M', 'S', ' Sin Domicilio', 2, '', '', '', '2014-08-13', NULL, '2014-08-13', '2014-08-13', 0, NULL, NULL, 'N', NULL, NULL, 2),
(105, 21180061, 'Presidente Rosa', '', 0, 1, 21180061, 'Presidente', 'Rosa Isabel', '1899-11-30', 'F', 'S', 'Mza 17 Lote 7 Bº Campo Contreras', 2, '', '', '385218267', '2014-08-21', '', '2014-08-21', '2014-08-21', 0, '', '', 'N', '', 1, 1),
(106, 18259920, 'Navelino Maria', '', 0, 1, 18259920, 'Navelino', 'Maria E.', '0000-00-00', 'F', 'S', 'Mza C Lote 5 Bº 1ra Ampl Altte Brown', 2, '', '', '', '2014-09-04', NULL, '2014-09-04', '2014-09-04', 0, NULL, NULL, 'N', NULL, NULL, 2),
(107, 36121716, 'Brandan Damian', '', 0, 1, 36121716, 'Brandan', 'Damian E.', '0000-00-00', 'M', 'S', 'Santiago Palacios N455 Bº Huaico Hondo', 2, '', '', '', '2014-09-04', NULL, '2014-09-04', '2014-09-04', 0, NULL, NULL, 'N', NULL, NULL, 2),
(108, 24063402, 'Carabajal Silvia', '', 0, 1, 24063402, 'Carabajal', 'Silvia Susana', '1975-09-14', 'F', 'C', 'Mza 53 Lote 15 Sector IPVU Bº Vinalar', 2, '', '', '155012427', '2015-03-02', '', '2015-03-02', '2052-12-31', 0, '', '', 'N', '', 1, 1),
(109, 38719228, 'Castaño María', '', 0, 1, 38719228, 'Castaño Ibarra', 'María de los Angeles', '1995-05-30', 'F', 'S', 'calle 63 entre Nº 753 13 y 15 Bª Ejercito Argentino', 2, '', '', '0385 154178895', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(110, 38642959, 'Villar Brenda', '', 0, 1, 38642959, 'Villar Rodriguez', 'Brenda', '1995-01-25', 'F', 'S', 'Bº los Flores II Camino a la Costa Mza I lote 24', 2, 'villar_brnda@hotmail.com', '', '155841931', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(111, 34913052, 'Musso Florencia', '', 0, 1, 34913052, 'Musso', 'Florencia Aldana', '1989-10-25', 'F', 'S', 'Bº Saint Germain Mza 53 Lote 23', 2, 'mussoaldana@hotmail.com', '', '154350629', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(112, 33208193, 'Di Santo Martín', '', 0, 1, 33208193, 'Di Santo', 'Martín', '1987-10-12', 'M', 'S', 'Zanjon (capital)', 2, '', '', '155993186', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(113, 32688666, 'Herrera Agustín', '', 0, 1, 32688666, 'Herrera', 'Agustín', '1986-11-05', 'F', 'S', 'Domingo Palacios Nº 216', 2, 'agucho_h@hotmail.com', '', '154068157', '2015-03-02', '', '2015-03-02', '2015-03-02', 0, '', '', 'N', '', 1, 1),
(114, 30241086, 'Espeche Guido', '', 3, 1, 30241086, 'Espeche Gerez', 'Guido', '1983-05-20', 'F', 'S', 'Alberto Riggi Nº 320', 2, 'guidoespeche@hotmail.com', '', '155953505', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(115, 33137314, 'Lopez Maria Eugenia', '', 0, 1, 33137314, 'Lopez Rodriguez', 'María Eugenia', '1987-12-01', 'F', 'S', 'Bº Ejercito Argentino Calle 64 y 18 Dpto 204 2º piso', 2, 'marulr3260@gmail.com', '', '154856878', '2015-03-02', '', '2015-03-02', '2050-12-31', 0, '', '', 'N', '', 1, 1),
(116, 242063402, 'Carabajal Silvia', '', 0, 0, 242063402, 'Carabajal', 'Silvia Susana', '1899-11-30', 'F', 'S', 'Mza 53 lote15 Bº Vinalar sector IPVU', 2, '', '', '', '2015-03-16', '', '2015-03-16', '2015-03-16', 0, '', '', 'N', '', 1, 1),
(118, 28048612, 'Arias Maria Eugenia', '', 0, 1, 28048612, 'Arias', 'Maria Eugenia', '1980-03-26', 'F', 'S', 'Chaco Nº 31 Bº Alberdi', 2, 'mreu90@hotmail.com', '', '3854965282', '2015-03-25', NULL, '2015-03-25', '2025-12-31', 0, NULL, NULL, 'N', NULL, 1, 1),
(119, 22653457, 'marottoli Lauro Hernan', '', 0, 1, 22653457, 'Marottoli', 'Lauro Hernan', '1972-03-02', 'M', 'C', 'Neuquen Nº 258Bº Francisco de Aguirre', 2, 'lauroacademia@hotmail.com.ar', '4257577', '3854832389', '2015-03-25', NULL, '2015-03-25', '2025-12-31', 0, NULL, NULL, 'N', NULL, 1, 1),
(120, 22669975, 'Luna Claudia', '', 0, 1, 22669975, 'Luna', 'Angela Claudia', '1972-10-28', 'F', 'S', 'Duplex Campo Contreras (S) Mza 35 L17', 2, 'claudia_luna12@hotmail.com.es', '', '155143729', '2015-04-08', '', '2015-03-01', '2035-12-31', 0, '', '', 'N', '', 1, 1),
(121, 38179228, '', '', 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 1),
(122, 28733431, 'Castaño Elizabet', '', 0, 1, 28733431, 'Castaño', 'Rita Elizabet', '1981-04-18', 'F', 'S', 'Calle 108 N° 2636 B° Borges', 2, 'ely.hsb.07@gmail.com', '4344104', '154267741', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', 1, 1),
(123, 29409500, 'Díaz Margarita', '', 0, 1, 29409500, 'Díaz', 'Margarita Soledad', '1982-05-04', 'F', 'S', 'Antonio Toloza 642 B° Industria', 2, '', '', '155754694', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', 1, 1),
(124, 32314734, 'Carrizo María', '', 0, 1, 32314734, 'Carrizo', 'María Julia Belén', '1986-03-08', 'F', 'S', 'Mza 77 Lote 19 B° Saint Germain', 2, '', '', '155065899', '0000-00-00', '', '0000-00-00', '0000-00-00', 0, '', '', 'N', '', 1, 1),
(125, 31414658, 'Orieta Magalí', '', 0, 1, 31414658, 'Orieta', 'Marta Magalí', '1984-11-18', 'F', 'S', 'Sofanor de la Silva 1er Pasaje N°588 B° Santa Rosa', 2, '', '156097615', '155797583', '1899-11-30', '', '1899-11-30', '1899-11-30', 0, '', '', 'N', '', 1, 1),
(126, 31305696, 'Lorenzo Agostina', '', 0, 1, 31305696, 'Lorenzo Aranda', 'María Agostina', '1985-03-26', 'F', 'S', 'Mza E lote 12 B° Mariano Moreno', 2, 'agostinainnamorato10@gmail.com', '', '155927316', '2016-07-13', '', '2016-07-13', '2038-12-31', 0, '', '', 'N', '', 1, 1),
(127, 24807563, 'Sokolic Silvina', '', 0, 1, 24807563, 'Sokolic', 'Claudia Silvina', '1975-11-29', 'F', 'C', 'Camino a las Marias el Puestito', 2, 'scilvinas@gmail.com', '', '156096037', '2016-10-27', '', '2016-10-27', '2016-10-27', 0, '', '', 'N', '', 1, 1),
(128, 38483409, 'Tarchini Matias', '', 0, 1, 38483409, 'Tarchini', 'Matias Nicolas', '1995-01-02', 'M', 'S', 'Mza 56 l 3 B° vinalar', 2, 'ti3m_2010@hotmail.com', '', '3854130230', '2018-05-07', '', '2018-05-07', '2077-05-01', 0, '', '', 'N', '', 1, 1),
(129, 18603992, '', '', 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 'N', NULL, NULL, 0),
(130, 18259955, 'Acuña Marcela', '', 0, 1, 18259955, 'Acuña', 'Marcela Teresita', '1899-11-30', 'F', 'S', 'Patrocinia Diaz 1841 mariano moreno 2da SAmp', 2, '', '6004318', '3854414321', '2018-06-11', NULL, '2018-06-11', '2060-06-11', 0, NULL, NULL, 'N', NULL, 1, 1),
(131, 39582686, 'Iñiguez Mauricio', '', 0, 1, 39582686, 'Iñiguez', 'Mauricio Javier', '0000-00-00', 'M', 'S', 'pasaje 229 numero 765 b colon', 2, '', '', '3855811784', '2018-06-11', NULL, '2018-06-11', '2060-06-11', 0, NULL, NULL, 'N', NULL, 1, 1),
(132, 185623566, 'Gabriela', NULL, 0, 1, 18603, 'Pece Zorrilla', 'Maria Gabriela', NULL, 'F', 'S', 'Mza 2 Lote 17 Bº Los Flores', 2, '', '', '3854381358', '2018-07-03', NULL, '2016-02-05', '2030-11-01', NULL, NULL, NULL, 'N', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_permiso`
--

CREATE TABLE `empleado_permiso` (
  `id_empleado_permiso` int(11) NOT NULL,
  `id_empleado_turno` int(11) DEFAULT NULL,
  `id_permiso` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_reloj`
--

CREATE TABLE `empleado_reloj` (
  `id_empleado_reloj` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_reloj` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `empleado_reloj`
--

INSERT INTO `empleado_reloj` (`id_empleado_reloj`, `id_empleado`, `id_reloj`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(67, 2, 1),
(68, 2, 2),
(69, 2, 3),
(220, 3, 1),
(221, 3, 2),
(222, 3, 3),
(316, 4, 1),
(318, 4, 2),
(320, 4, 3),
(85, 5, 1),
(86, 5, 2),
(87, 5, 3),
(214, 6, 1),
(215, 6, 2),
(216, 6, 3),
(313, 7, 1),
(314, 7, 2),
(315, 7, 3),
(175, 8, 1),
(176, 8, 2),
(177, 8, 3),
(37, 9, 1),
(38, 9, 2),
(39, 9, 3),
(64, 10, 1),
(65, 10, 2),
(66, 10, 3),
(40, 11, 1),
(41, 11, 2),
(42, 11, 3),
(130, 12, 1),
(131, 12, 2),
(132, 12, 3),
(317, 13, 1),
(319, 13, 2),
(321, 13, 3),
(73, 14, 1),
(74, 14, 2),
(75, 14, 3),
(181, 15, 1),
(182, 15, 2),
(183, 15, 3),
(25, 16, 1),
(26, 16, 2),
(27, 16, 3),
(70, 17, 1),
(71, 17, 2),
(72, 17, 3),
(184, 18, 1),
(185, 18, 2),
(186, 18, 3),
(172, 19, 1),
(173, 19, 2),
(174, 19, 3),
(4, 20, 1),
(5, 20, 2),
(6, 20, 3),
(103, 21, 1),
(104, 21, 2),
(105, 21, 3),
(76, 22, 1),
(77, 22, 2),
(78, 22, 3),
(202, 23, 1),
(203, 23, 2),
(204, 23, 3),
(115, 24, 1),
(116, 24, 2),
(117, 24, 3),
(100, 25, 1),
(101, 25, 2),
(102, 25, 3),
(136, 26, 1),
(137, 26, 2),
(138, 26, 3),
(142, 27, 1),
(239, 27, 2),
(240, 27, 3),
(109, 28, 1),
(110, 28, 2),
(111, 28, 3),
(31, 29, 1),
(32, 29, 2),
(33, 29, 3),
(358, 30, 1),
(365, 30, 2),
(371, 30, 3),
(61, 31, 1),
(62, 31, 2),
(63, 31, 3),
(199, 32, 1),
(200, 32, 2),
(201, 32, 3),
(196, 33, 1),
(197, 33, 2),
(198, 33, 3),
(359, 34, 1),
(367, 34, 2),
(373, 34, 3),
(19, 35, 1),
(20, 35, 2),
(21, 35, 3),
(7, 36, 1),
(8, 36, 2),
(9, 36, 3),
(22, 37, 1),
(23, 37, 2),
(24, 37, 3),
(360, 38, 1),
(368, 38, 2),
(374, 38, 3),
(28, 39, 1),
(29, 39, 2),
(30, 39, 3),
(166, 40, 1),
(167, 40, 2),
(168, 40, 3),
(52, 41, 1),
(53, 41, 2),
(54, 41, 3),
(211, 42, 1),
(212, 42, 2),
(213, 42, 3),
(121, 43, 1),
(122, 43, 2),
(123, 43, 3),
(112, 44, 1),
(113, 44, 2),
(114, 44, 3),
(190, 45, 1),
(191, 45, 2),
(192, 45, 3),
(361, 46, 1),
(366, 46, 2),
(372, 46, 3),
(362, 47, 1),
(369, 47, 2),
(375, 47, 3),
(34, 48, 1),
(35, 48, 2),
(36, 48, 3),
(217, 49, 1),
(218, 49, 2),
(219, 49, 3),
(133, 50, 1),
(134, 50, 2),
(135, 50, 3),
(118, 51, 1),
(119, 51, 2),
(120, 51, 3),
(363, 52, 1),
(370, 52, 2),
(376, 52, 3),
(187, 53, 1),
(188, 53, 2),
(189, 53, 3),
(157, 54, 1),
(158, 54, 2),
(159, 54, 3),
(55, 55, 1),
(56, 55, 2),
(57, 55, 3),
(88, 56, 1),
(89, 56, 2),
(90, 56, 3),
(43, 57, 1),
(44, 57, 2),
(45, 57, 3),
(169, 58, 1),
(170, 58, 2),
(171, 58, 3),
(127, 59, 1),
(128, 59, 2),
(129, 59, 3),
(94, 60, 1),
(95, 60, 2),
(96, 60, 3),
(49, 61, 1),
(50, 61, 2),
(51, 61, 3),
(16, 62, 1),
(17, 62, 2),
(18, 62, 3),
(160, 63, 1),
(161, 63, 2),
(162, 63, 3),
(145, 64, 1),
(146, 64, 2),
(147, 64, 3),
(208, 65, 1),
(209, 65, 2),
(210, 65, 3),
(205, 66, 1),
(206, 66, 2),
(207, 66, 3),
(193, 67, 1),
(194, 67, 2),
(195, 67, 3),
(178, 68, 1),
(179, 68, 2),
(180, 68, 3),
(139, 69, 1),
(140, 69, 2),
(141, 69, 3),
(82, 70, 1),
(83, 70, 2),
(84, 70, 3),
(79, 71, 1),
(80, 71, 2),
(81, 71, 3),
(10, 72, 1),
(11, 72, 2),
(12, 72, 3),
(148, 73, 1),
(149, 73, 2),
(150, 73, 3),
(151, 74, 1),
(152, 74, 2),
(153, 74, 3),
(283, 75, 1),
(282, 75, 2),
(225, 75, 3),
(275, 76, 1),
(274, 76, 2),
(304, 76, 3),
(289, 77, 1),
(288, 77, 2),
(229, 77, 3),
(268, 78, 1),
(269, 78, 2),
(230, 78, 3),
(277, 79, 1),
(276, 79, 2),
(237, 79, 3),
(273, 80, 1),
(272, 80, 2),
(223, 80, 3),
(266, 81, 1),
(267, 81, 2),
(224, 81, 3),
(249, 82, 1),
(247, 82, 2),
(226, 82, 3),
(271, 83, 1),
(270, 83, 2),
(227, 83, 3),
(297, 84, 1),
(296, 84, 2),
(228, 84, 3),
(262, 85, 1),
(263, 85, 2),
(231, 85, 3),
(245, 86, 1),
(244, 86, 2),
(232, 86, 3),
(293, 87, 1),
(292, 87, 2),
(233, 87, 3),
(253, 88, 1),
(254, 88, 2),
(234, 88, 3),
(264, 89, 1),
(265, 89, 2),
(235, 89, 3),
(291, 90, 1),
(290, 90, 2),
(236, 90, 3),
(309, 91, 1),
(308, 91, 2),
(238, 91, 3),
(256, 94, 1),
(257, 94, 2),
(258, 94, 3),
(287, 95, 1),
(286, 95, 2),
(298, 95, 3),
(250, 99, 1),
(251, 99, 2),
(252, 99, 3),
(281, 100, 1),
(280, 100, 2),
(302, 100, 3),
(259, 101, 1),
(260, 101, 2),
(261, 101, 3),
(279, 102, 1),
(278, 102, 2),
(303, 102, 3),
(295, 104, 1),
(294, 104, 2),
(310, 104, 3),
(242, 105, 1),
(312, 105, 2),
(241, 105, 3),
(305, 106, 1),
(306, 106, 2),
(307, 106, 3),
(299, 107, 1),
(300, 107, 2),
(301, 107, 3),
(328, 108, 1),
(329, 108, 2),
(330, 108, 3),
(331, 109, 1),
(332, 109, 2),
(333, 109, 3),
(343, 110, 1),
(344, 110, 2),
(345, 110, 3),
(340, 111, 1),
(341, 111, 2),
(342, 111, 3),
(334, 112, 1),
(335, 112, 2),
(336, 112, 3),
(322, 113, 1),
(323, 113, 2),
(324, 113, 3),
(337, 114, 1),
(338, 114, 2),
(339, 114, 3),
(325, 115, 1),
(326, 115, 2),
(327, 115, 3),
(346, 118, 1),
(347, 118, 2),
(348, 118, 3),
(349, 119, 1),
(350, 119, 2),
(351, 119, 3),
(352, 120, 1),
(353, 120, 2),
(354, 120, 3),
(364, 121, 1),
(387, 122, 1),
(388, 122, 2),
(377, 122, 3),
(385, 123, 1),
(386, 123, 2),
(378, 123, 3),
(383, 124, 1),
(384, 124, 2),
(379, 124, 3),
(381, 125, 1),
(382, 125, 2),
(380, 125, 3),
(390, 126, 1),
(391, 126, 2),
(389, 126, 3),
(392, 127, 1),
(393, 127, 2),
(394, 127, 3),
(398, 128, 1),
(397, 128, 2),
(395, 128, 3),
(396, 129, 3),
(399, 130, 1),
(400, 130, 2),
(401, 130, 3),
(402, 131, 1),
(403, 131, 2),
(404, 131, 3),
(405, 132, 1),
(406, 132, 2),
(407, 132, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_turno`
--

CREATE TABLE `empleado_turno` (
  `id_empleado_turno` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_turno` int(11) DEFAULT NULL,
  `desde` date DEFAULT NULL COMMENT 'Desde cuando empieza a regir',
  `hasta` date DEFAULT NULL COMMENT 'Hasta cuando rige (puede ser null lo cual indica sin fecha de corte)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `empleado_turno`
--

INSERT INTO `empleado_turno` (`id_empleado_turno`, `id_empleado`, `id_turno`, `desde`, `hasta`) VALUES
(1, 1, 1, '2013-07-01', NULL),
(7, 16, 1, '2013-07-01', NULL),
(28, 28, 1, '2013-07-01', NULL),
(47, 32, 1, '2013-07-01', NULL),
(53, 1, 2, '2013-07-01', NULL),
(59, 16, 2, '2013-07-01', NULL),
(80, 28, 2, '2013-07-01', NULL),
(99, 32, 2, '2013-07-01', NULL),
(105, 1, 3, '2013-07-16', '2013-07-26'),
(111, 16, 3, '2013-07-16', '2013-07-26'),
(132, 28, 3, '2013-07-16', '2013-07-26'),
(151, 32, 3, '2013-07-16', '2013-07-26'),
(160, 1, 1, '2013-07-01', NULL),
(168, 16, 1, '2013-07-01', NULL),
(186, 71, 1, '2013-07-01', NULL),
(187, 70, 1, '2013-07-01', NULL),
(196, 28, 1, '2013-07-01', NULL),
(208, 64, 1, '2013-07-01', NULL),
(210, 74, 1, '2013-07-01', NULL),
(224, 67, 1, '2013-07-01', NULL),
(226, 32, 1, '2013-07-01', NULL),
(234, 1, 2, '2013-07-01', NULL),
(242, 16, 2, '2013-07-01', NULL),
(260, 71, 2, '2013-07-01', NULL),
(261, 70, 2, '2013-07-01', NULL),
(270, 28, 2, '2013-07-01', NULL),
(282, 64, 2, '2013-07-01', NULL),
(284, 74, 2, '2013-07-01', NULL),
(298, 67, 2, '2013-07-01', NULL),
(300, 32, 2, '2013-07-01', NULL),
(308, 1, 1, '2014-01-01', NULL),
(316, 16, 1, '2014-01-01', NULL),
(334, 71, 1, '2014-01-01', NULL),
(335, 70, 1, '2014-01-01', NULL),
(344, 28, 1, '2014-01-01', NULL),
(356, 64, 1, '2014-01-01', NULL),
(358, 74, 1, '2014-01-01', NULL),
(372, 67, 1, '2014-01-01', NULL),
(374, 32, 1, '2014-01-01', NULL),
(383, 25, 1, '2013-01-07', '2014-12-31'),
(384, 15, 1, '2013-01-07', '2014-12-31'),
(387, 37, 1, '2013-01-07', '2014-12-31'),
(388, 57, 1, '2013-01-07', '2014-12-31'),
(390, 41, 1, '2013-01-07', '2014-12-31'),
(391, 55, 1, '2014-05-05', '2014-12-31'),
(392, 31, 1, '2013-01-07', '2014-12-31'),
(393, 10, 5, '2014-05-05', '2014-12-31'),
(394, 17, 1, '2014-05-05', '2014-12-31'),
(395, 43, 1, '2014-05-05', '2014-12-31'),
(396, 29, 1, '2014-05-05', '2014-12-31'),
(397, 14, 1, '2014-05-05', '2014-12-31'),
(398, 22, 1, '2014-05-05', '2014-12-31'),
(399, 5, 2, '2014-05-05', '2014-12-31'),
(400, 56, 4, '2014-05-05', '2014-12-31'),
(403, 21, 1, '2014-05-05', '2014-12-31'),
(404, 44, 1, '2014-05-05', '2014-12-31'),
(405, 24, 1, '2014-05-05', '2014-12-31'),
(407, 12, 1, '2014-05-05', '2014-12-31'),
(408, 50, 1, '2014-05-05', '2014-12-31'),
(409, 26, 2, '2014-05-05', '2014-12-31'),
(410, 69, 1, '2014-05-05', '2014-12-31'),
(411, 27, 4, '2014-05-05', '2014-12-31'),
(414, 58, 4, '2014-05-05', '2014-12-31'),
(415, 19, 1, '2014-05-05', '2014-12-31'),
(416, 8, 1, '2014-05-05', '2014-12-31'),
(417, 68, 1, '2014-05-05', '2014-12-31'),
(419, 33, 4, '2014-05-05', '2014-12-31'),
(420, 23, 1, '2014-05-05', '2014-12-31'),
(422, 65, 1, '2014-05-05', '2014-12-31'),
(423, 42, 1, '2014-05-05', '2014-12-31'),
(424, 6, 1, '2014-05-05', '2014-12-31'),
(425, 3, 1, '2014-05-05', '2014-12-31'),
(426, 53, 2, '2014-05-05', '2014-12-31'),
(427, 73, 2, '2014-05-05', '2014-12-31'),
(428, 9, 1, '2014-05-05', '2014-12-31'),
(429, 72, 2, '2014-05-05', '2014-12-31'),
(430, 2, 1, '2014-05-05', '2014-12-31'),
(431, 39, 2, '2014-05-05', '2014-12-31'),
(432, 18, 2, '2014-05-05', '2014-12-31'),
(433, 54, 6, '2014-05-05', '2014-12-31'),
(434, 35, 1, '2014-05-05', '2014-12-31'),
(435, 86, 1, '2014-08-01', '2022-12-31'),
(436, 18, 6, '2014-10-03', NULL),
(438, 105, 1, '2014-08-01', '2014-12-31'),
(439, 54, 2, '2014-12-15', NULL),
(440, 11, 1, '2015-01-01', '2015-12-31'),
(441, 13, 1, '2015-01-01', '2015-12-31'),
(442, 113, 1, '2015-01-01', '2015-12-31'),
(443, 115, 1, '2015-01-01', '2015-12-31'),
(444, 108, 1, '2015-01-01', '2015-12-31'),
(445, 109, 1, '2015-01-01', '2015-12-31'),
(446, 112, 1, '2015-01-01', '2015-12-31'),
(447, 114, 1, '2015-01-01', '2015-12-31'),
(448, 60, 1, '2015-01-01', '2015-12-31'),
(449, 111, 1, '2015-01-01', '2015-12-31'),
(450, 110, 1, '2015-03-02', '2015-12-31'),
(451, 118, 1, '2015-03-01', '2015-12-31'),
(452, 119, 1, '2015-03-01', '2015-12-31'),
(453, 120, 1, '2015-03-01', '2015-12-31'),
(455, 7, 1, '2013-01-01', '2015-12-31'),
(456, 26, 2, '2015-01-01', NULL),
(457, 48, 1, '2016-01-01', '2016-12-30'),
(458, 62, 4, '2016-01-04', '2016-12-31'),
(459, 61, 4, '2016-01-01', '2016-12-31'),
(460, 63, 1, '2016-01-01', '2016-12-31'),
(461, 66, 1, '2016-01-01', '2016-12-31'),
(462, 125, 1, '2016-03-01', '2016-12-31'),
(463, 124, 1, '2016-03-01', '2016-12-31'),
(464, 123, 1, '2016-03-01', '2016-12-31'),
(466, 122, 1, '2016-02-01', '2016-12-30'),
(467, 126, 1, '2016-07-15', '2016-12-31'),
(468, 126, 1, '2016-06-01', '2032-10-31'),
(469, 127, 1, '2016-10-01', '2037-10-31'),
(470, 40, 1, '2016-12-01', '2016-12-31'),
(474, 51, 1, '2018-01-01', '2019-01-01'),
(476, 128, 1, '2018-03-01', '2052-06-30'),
(478, 131, 1, '2018-05-01', '2052-06-30'),
(479, 26, 1, '2017-01-01', '2022-12-31'),
(480, 132, 1, '2018-01-02', '2020-07-01'),
(481, 36, 1, '2017-06-01', '2030-07-04');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `empleado_view`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `empleado_view` (
`id_empleado` int(11)
,`enroll_number` int(11)
,`name` varchar(23)
,`nro_doc` int(11)
,`apellido` varchar(50)
,`nombre` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fichaje`
--

CREATE TABLE `fichaje` (
  `id_fichaje` int(11) NOT NULL,
  `id_empleado_reloj` int(11) DEFAULT NULL,
  `verify_mode` tinyint(4) DEFAULT NULL COMMENT 'Forma que ficho (Huella, Pin, Tarjeta?)',
  `inout_mode` tinyint(4) DEFAULT NULL COMMENT '0=Salida?, 1=Entrada?',
  `fecha_hora` datetime DEFAULT NULL,
  `workcode` tinyint(4) DEFAULT NULL COMMENT '?',
  `tipo` enum('R','M','V') COLLATE utf8_spanish_ci DEFAULT 'R' COMMENT 'R=Real (reloj), M=Modificado, V=Virtual (Agregado por el usuario)',
  `id_usuario` int(11) DEFAULT NULL,
  `ult_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `huella`
--

CREATE TABLE `huella` (
  `id_huella` int(11) NOT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `finger_index` tinyint(4) DEFAULT NULL COMMENT 'Nro de dedo',
  `flag` tinyint(4) DEFAULT NULL,
  `tmp_length` int(11) DEFAULT NULL COMMENT 'Length del campo Data',
  `tmp_data` text COLLATE utf8_spanish_ci COMMENT 'Huella'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad`
--

CREATE TABLE `localidad` (
  `id_localidad` int(11) NOT NULL,
  `id_departamento` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cp` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lugar_trabajo`
--

CREATE TABLE `lugar_trabajo` (
  `id_lugar_trabajo` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `lugar_trabajo`
--

INSERT INTO `lugar_trabajo` (`id_lugar_trabajo`, `descrip`) VALUES
(1, 'Defensoria del Pueblo'),
(2, 'Escribania de Gobierno');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `organigrama`
--

CREATE TABLE `organigrama` (
  `id_organigrama` int(11) NOT NULL,
  `id_padre` int(11) DEFAULT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cant_hijos` tinyint(4) DEFAULT NULL,
  `cant_empleados` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paramet`
--

CREATE TABLE `paramet` (
  `id_paramet` int(11) NOT NULL,
  `json` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paramet`
--

INSERT INTO `paramet` (`id_paramet`, `json`) VALUES
(1, '{}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

CREATE TABLE `permiso` (
  `id_permiso` int(11) NOT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada` tinyint(1) DEFAULT NULL COMMENT 'Permiso en la Entrada',
  `salida` tinyint(1) DEFAULT NULL COMMENT 'Permiso en la Salida',
  `pagas` tinyint(1) DEFAULT NULL COMMENT 'Si dicho permiso afecta en el sueldo',
  `activo` tinyint(1) DEFAULT NULL COMMENT 'S=Habilitado, N=Deshabilitado',
  `hora_asignacion_limite` time DEFAULT NULL,
  `primer_aviso` tinyint(4) DEFAULT NULL,
  `primer_mensaje` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `segundo_aviso` tinyint(4) DEFAULT NULL,
  `segundo_mensaje` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`id_permiso`, `id_lugar_trabajo`, `descrip`, `entrada`, `salida`, `pagas`, `activo`, `hora_asignacion_limite`, `primer_aviso`, `primer_mensaje`, `segundo_aviso`, `segundo_mensaje`) VALUES
(1, 1, 'Maternidad', 1, 1, 1, 1, '13:00:00', 0, NULL, 0, NULL),
(2, 1, 'Enfermedad', 1, 1, 1, 1, '13:00:00', 0, NULL, 0, NULL),
(3, 1, 'Monitoreo', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(4, 1, 'Estudio', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(5, 1, 'Particular', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(6, 1, '2 Horas Entrada', 1, 0, 0, 1, '17:00:00', 0, NULL, 0, NULL),
(7, 1, 'Lactancia', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(8, 1, 'Familiar Enfermo', 1, 0, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(9, 1, 'Injustificado 09:00hs', 1, 0, 0, 0, '13:00:00', 0, NULL, 0, NULL),
(10, 1, 'Lic. Proporcional', 1, 0, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(11, 1, 'Comision', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(12, 1, 'Com. Lago', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(13, 1, 'Cambi Turno Provisorio', 1, 0, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(14, 1, 'Duelo', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(15, 1, 'DUELO FAMILIAR', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(16, 1, 'Vacaciones', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(17, 1, 'DONADOR DE SANGRE', 1, 0, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(18, 1, '1 Hora Entrada', 1, 0, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(19, 1, '1 Hora Salida', 0, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(20, 1, '2 Horas Salida', 0, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(21, 1, 'Cambio MONITOREO', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(22, 1, 'INSPECCION', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(23, 1, 'JUSTIFICACION SUPERIOR', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(24, 1, 'FRANCO COMPENSATORIO', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(25, 1, 'Lic. Matrimonio', 1, 1, 0, 1, '13:00:00', 0, NULL, 0, NULL),
(26, 1, 'RECESO INVERNAL', 1, 1, 1, 1, '13:00:00', 0, NULL, 0, NULL),
(27, 1, 'receso Enero', 1, 1, 1, 0, '13:00:00', 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE `provincia` (
  `id_provincia` int(11) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reloj`
--

CREATE TABLE `reloj` (
  `id_reloj` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `host` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL COMMENT 'ip o host donde se encuentra el reloj',
  `ultima_sincro` datetime DEFAULT NULL COMMENT 'Fecha y Hora de ultima sincronizacion'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `reloj`
--

INSERT INTO `reloj` (`id_reloj`, `descrip`, `host`, `ultima_sincro`) VALUES
(1, 'Unico', '10.0.0.5', NULL),
(2, 'Reloj 1', '10.0.0.6', NULL),
(3, 'Reloj 2', '10.0.0.7', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tolerancia`
--

CREATE TABLE `tolerancia` (
  `id_tolerancia` int(11) NOT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada_extras` tinyint(1) DEFAULT NULL COMMENT 'Son horas extras antes de la hora de entrada',
  `e_fichada` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para fichada normal',
  `e_tolerable` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para tardanza tolerable',
  `e_tardanza` tinyint(4) DEFAULT '0' COMMENT 'Min. desde entrada para tardanza',
  `e_30minutos` tinyint(4) DEFAULT NULL,
  `e_60minutos` tinyint(4) DEFAULT NULL,
  `salida_extras` tinyint(1) DEFAULT NULL COMMENT 'Son horas extras despues de hora de salida',
  `s_fichada` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para fichada normal',
  `s_tolerable` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para salida tolerable',
  `s_abandono` tinyint(4) DEFAULT '0' COMMENT 'Min. antes salida para salida con abandono de trabajo',
  `desde` date DEFAULT NULL COMMENT 'Desde cuando rige',
  `hasta` date DEFAULT NULL COMMENT 'Puede ser NULL porque no se define hasta cuando se tiene en cuenta',
  `control_entrada` tinyint(1) DEFAULT NULL,
  `control_salida` tinyint(1) DEFAULT NULL,
  `total_minutos` smallint(4) DEFAULT NULL,
  `limite_tardanzas` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tolerancia`
--

INSERT INTO `tolerancia` (`id_tolerancia`, `id_lugar_trabajo`, `descrip`, `entrada_extras`, `e_fichada`, `e_tolerable`, `e_tardanza`, `e_30minutos`, `e_60minutos`, `salida_extras`, `s_fichada`, `s_tolerable`, `s_abandono`, `desde`, `hasta`, `control_entrada`, `control_salida`, `total_minutos`, `limite_tardanzas`) VALUES
(1, 1, 'Normal', 0, 0, 10, 30, 0, 0, 0, 0, 30, 100, '2000-11-03', '2030-12-31', 1, 1, 60, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turno`
--

CREATE TABLE `turno` (
  `id_turno` int(11) NOT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL,
  `tipo` enum('F','X','V') COLLATE utf8_spanish_ci DEFAULT 'F' COMMENT 'F=Fijo, X=Flexible, V=Variable',
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `entrada` time DEFAULT NULL COMMENT 'Fijos y Variables',
  `salida` time DEFAULT NULL COMMENT 'Fijos y Variables',
  `lu` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `ma` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `mi` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `ju` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `vi` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `sa` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `do` tinyint(1) DEFAULT NULL COMMENT 'Fijos y Flexibles',
  `cant_horas` tinyint(4) DEFAULT NULL COMMENT 'Cantidad de Horas Diarias (flexibles)',
  `activo` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `turno`
--

INSERT INTO `turno` (`id_turno`, `id_lugar_trabajo`, `tipo`, `descrip`, `entrada`, `salida`, `lu`, `ma`, `mi`, `ju`, `vi`, `sa`, `do`, `cant_horas`, `activo`) VALUES
(1, 1, 'F', 'Mañana', '07:30:00', '13:00:00', 1, 1, 1, 1, 1, 0, 0, 0, 1),
(2, 1, 'F', 'Horas extras', '13:00:00', '19:30:00', 1, 1, 1, 1, 1, 0, 0, 0, 1),
(3, 1, 'F', 'Feria', '08:30:00', '12:30:00', 1, 1, 1, 1, 1, 0, 0, 0, 1),
(4, 1, 'F', 'Horas Extras  1', '08:00:00', '13:30:00', 1, 1, 1, 1, 1, 0, 0, 0, 1),
(5, 1, 'F', 'Horas Extras  2', '08:30:00', '14:00:00', 1, 1, 1, 1, 1, 0, 0, 0, 1),
(6, 1, 'F', 'Prefijado 1', '14:00:00', '19:30:00', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 1, 'X', 'Prefijado 2', '00:00:00', '00:00:00', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `id_ubicacion` int(11) NOT NULL,
  `id_padre` int(11) DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`id_ubicacion`, `id_padre`, `descrip`) VALUES
(1, 0, ''),
(2, 1, 'Argentina'),
(3, 2, 'Santiago del Estero'),
(4, 3, 'Capital'),
(5, 4, 'Santiago del Estero'),
(6, 1, 'Brasil'),
(7, 3, 'Banda'),
(8, 7, 'La Banda'),
(9, 2, 'Cordoba'),
(10, 9, 'Capital'),
(11, 10, 'Cordoba');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(35) COLLATE utf8_spanish_ci DEFAULT NULL,
  `password` varchar(35) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo` enum('A','U') COLLATE utf8_spanish_ci DEFAULT 'U' COMMENT 'A=Admin, U=Usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `usuario`, `password`, `tipo`) VALUES
(1, 'root', '63a9f0ea7bb98050796b649e85481845', 'A'),
(2, 'usuario', 'f8032d5cae3de20fcec887f395ec9a6a', 'U'),
(3, 'rodrigodelarua', 'b3bc43a3fc65c100c11ad4d7757151e4', 'A'),
(4, 'gustavodelasilva', 'd41d8cd98f00b204e9800998ecf8427e', 'A'),
(5, 'roxanacasares', 'a8f10f667f071064279764353dd518ff', 'A'),
(6, 'enriqueheredia', '8b9127934238e9a03691225c734a0a71', 'U'),
(7, 'diazachaval', 'ad46198538fd10685c6b1e5fead3eff6', 'A'),
(8, 'guidoespeche', '00993e01a0917beda6ff521af894feca', 'A'),
(9, 'diegodiaz', '346767f348f9561a606cf675361d2a03', 'U'),
(10, 'martaorieta', 'DADO DE BAJA', 'U'),
(11, 'angelescastaño', 'DADO DE BAJA', 'U'),
(12, 'brendavillar', 'DADO DE BAJA', 'U'),
(13, 'rosapresidente', 'DADO DE BAJA', 'U'),
(14, 'agostinalorenzo', 'DADO DE BAJA', 'U'),
(15, 'maguidiaz', 'DADO DE BAJA', 'U'),
(16, 'dellaringacecilia', '1d7c0fb835ae2ef51257c1bf4dd4371e', 'U'),
(17, 'lionelsuarez', 'd541c15ec3dfb4aa69bde0eb48865a59', 'A'),
(18, 'luismorales', '7d387428c247672452b7de2cc6e60c1f', 'A'),
(19, 'claudialuna', '8bb3575e8d391e19ac61eaaee2674fdb', 'U'),
(20, 'davidgreco', '7f90e893f80c2846a691c9a04512dc39', 'U'),
(21, 'cinthiacampos', 'ba59babe10d4cbfd5c5b3b02890bee3d', 'U');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_lugar_trabajo`
--

CREATE TABLE `usuario_lugar_trabajo` (
  `id_usuario` int(11) DEFAULT NULL,
  `id_lugar_trabajo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `usuario_lugar_trabajo`
--

INSERT INTO `usuario_lugar_trabajo` (`id_usuario`, `id_lugar_trabajo`) VALUES
(1, 1),
(1, 2),
(6, 2),
(2, 1),
(7, 1),
(8, 1),
(9, 1),
(11, 1),
(12, 1),
(14, 1),
(15, 1),
(16, 1),
(10, 1),
(13, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(5, 1),
(4, 1),
(3, 1),
(21, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `_auditoria`
--

CREATE TABLE `_auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tags` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_registro` int(11) DEFAULT NULL,
  `mysql_query` mediumtext COLLATE utf8_spanish_ci,
  `descrip` mediumtext COLLATE utf8_spanish_ci,
  `fecha_hora` datetime DEFAULT NULL,
  `ip` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `json` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura para la vista `empleado`
--
DROP TABLE IF EXISTS `empleado`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `empleado`  AS  select `empleado_view`.`id_empleado` AS `id_empleado`,`empleado_view`.`enroll_number` AS `enroll_number`,`empleado_view`.`name` AS `name`,`empleado_view`.`nro_doc` AS `nro_doc`,`empleado_view`.`apellido` AS `apellido`,`empleado_view`.`nombre` AS `nombre`,`empleado_datos`.`privilege` AS `privilege`,`empleado_datos`.`enabled` AS `enabled`,`empleado_datos`.`id_lugar_trabajo` AS `id_lugar_trabajo`,`empleado_datos`.`id_tolerancia` AS `id_tolerancia` from (`empleado_view` left join `empleado_datos` on((`empleado_view`.`id_empleado` = `empleado_datos`.`id_empleado`))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `empleado_view`
--
DROP TABLE IF EXISTS `empleado_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `empleado_view`  AS  select `empleado_ori`.`id_empleado` AS `id_empleado`,`empleado_ori`.`enroll_number` AS `enroll_number`,`empleado_ori`.`name` AS `name`,`empleado_ori`.`nro_doc` AS `nro_doc`,`empleado_ori`.`apellido` AS `apellido`,`empleado_ori`.`nombre` AS `nombre` from `empleado_ori` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id_departamento`),
  ADD KEY `fk_departamento_provincia1` (`id_provincia`);

--
-- Indices de la tabla `empleado_datos`
--
ALTER TABLE `empleado_datos`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `empleado_ori`
--
ALTER TABLE `empleado_ori`
  ADD PRIMARY KEY (`id_empleado`),
  ADD UNIQUE KEY `enroll_number_UNIQUE` (`enroll_number`),
  ADD UNIQUE KEY `enroll_number` (`enroll_number`),
  ADD KEY `fk_empleado_localidad1` (`id_ubicacion`),
  ADD KEY `fk_empleado_organigrama1` (`id_organigrama`),
  ADD KEY `fk_empleado_tolerancia1` (`id_tolerancia`);

--
-- Indices de la tabla `empleado_permiso`
--
ALTER TABLE `empleado_permiso`
  ADD PRIMARY KEY (`id_empleado_permiso`),
  ADD KEY `fk_empleado_permiso_empleado_turno1` (`id_empleado_turno`),
  ADD KEY `fk_empleado_permiso_permiso1` (`id_permiso`);

--
-- Indices de la tabla `empleado_reloj`
--
ALTER TABLE `empleado_reloj`
  ADD PRIMARY KEY (`id_empleado_reloj`),
  ADD UNIQUE KEY `id_empleado` (`id_empleado`,`id_reloj`),
  ADD KEY `fk_empleado_reloj_empleado1` (`id_empleado`),
  ADD KEY `fk_empleado_reloj_reloj1` (`id_reloj`);

--
-- Indices de la tabla `empleado_turno`
--
ALTER TABLE `empleado_turno`
  ADD PRIMARY KEY (`id_empleado_turno`),
  ADD KEY `fk_empleado_turno_empleado` (`id_empleado`),
  ADD KEY `fk_empleado_turno_turno1` (`id_turno`);

--
-- Indices de la tabla `fichaje`
--
ALTER TABLE `fichaje`
  ADD PRIMARY KEY (`id_fichaje`),
  ADD KEY `fk_fichaje_empleado_reloj1` (`id_empleado_reloj`);

--
-- Indices de la tabla `huella`
--
ALTER TABLE `huella`
  ADD PRIMARY KEY (`id_huella`),
  ADD KEY `fk_huella_empleado1` (`id_empleado`);

--
-- Indices de la tabla `localidad`
--
ALTER TABLE `localidad`
  ADD PRIMARY KEY (`id_localidad`),
  ADD KEY `fk_localidad_departamento1` (`id_departamento`);

--
-- Indices de la tabla `lugar_trabajo`
--
ALTER TABLE `lugar_trabajo`
  ADD PRIMARY KEY (`id_lugar_trabajo`);

--
-- Indices de la tabla `organigrama`
--
ALTER TABLE `organigrama`
  ADD PRIMARY KEY (`id_organigrama`);

--
-- Indices de la tabla `paramet`
--
ALTER TABLE `paramet`
  ADD PRIMARY KEY (`id_paramet`);

--
-- Indices de la tabla `permiso`
--
ALTER TABLE `permiso`
  ADD PRIMARY KEY (`id_permiso`);

--
-- Indices de la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indices de la tabla `reloj`
--
ALTER TABLE `reloj`
  ADD PRIMARY KEY (`id_reloj`);

--
-- Indices de la tabla `tolerancia`
--
ALTER TABLE `tolerancia`
  ADD PRIMARY KEY (`id_tolerancia`);

--
-- Indices de la tabla `turno`
--
ALTER TABLE `turno`
  ADD PRIMARY KEY (`id_turno`),
  ADD UNIQUE KEY `nombre_UNIQUE` (`descrip`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`id_ubicacion`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- Indices de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
  MODIFY `id_departamento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleado_ori`
--
ALTER TABLE `empleado_ori`
  MODIFY `id_empleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT de la tabla `empleado_permiso`
--
ALTER TABLE `empleado_permiso`
  MODIFY `id_empleado_permiso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleado_reloj`
--
ALTER TABLE `empleado_reloj`
  MODIFY `id_empleado_reloj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=408;

--
-- AUTO_INCREMENT de la tabla `empleado_turno`
--
ALTER TABLE `empleado_turno`
  MODIFY `id_empleado_turno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=482;

--
-- AUTO_INCREMENT de la tabla `fichaje`
--
ALTER TABLE `fichaje`
  MODIFY `id_fichaje` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `huella`
--
ALTER TABLE `huella`
  MODIFY `id_huella` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `localidad`
--
ALTER TABLE `localidad`
  MODIFY `id_localidad` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `lugar_trabajo`
--
ALTER TABLE `lugar_trabajo`
  MODIFY `id_lugar_trabajo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `organigrama`
--
ALTER TABLE `organigrama`
  MODIFY `id_organigrama` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `permiso`
--
ALTER TABLE `permiso`
  MODIFY `id_permiso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `provincia`
--
ALTER TABLE `provincia`
  MODIFY `id_provincia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reloj`
--
ALTER TABLE `reloj`
  MODIFY `id_reloj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tolerancia`
--
ALTER TABLE `tolerancia`
  MODIFY `id_tolerancia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `turno`
--
ALTER TABLE `turno`
  MODIFY `id_turno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `id_ubicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
